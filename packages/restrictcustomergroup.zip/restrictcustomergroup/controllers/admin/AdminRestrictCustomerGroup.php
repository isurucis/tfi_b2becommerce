<?php
/**
* NOTICE OF LICENSE
*
* This source file is subject to the Open Software License (OSL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/osl-3.0.php
*
* @author    FMM Modules
* @copyright FMM Modules
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*/

class AdminRestrictCustomerGroupController extends ModuleAdminController
{
    public function __construct()
    {
        $this->className = 'Rcg';
        $this->table = 'restrictcustomergroup';
        $this->identifier = 'id_restrictcustomergroup';
        $this->lang = false;
        $this->deleted = false;
        $this->colorOnBackground = false;
        $this->bootstrap = true;
        parent::__construct();
        $this->context = Context::getContext();

        $this->fields_list = array(
            'id_restrictcustomergroup' => array(
                'title'     => 'ID',
                'width' => 25
            ),
            'title' => array(
                'title'     => $this->module->l('Title'),
                'width' => 'auto'
            ),
            'active' => array(
                'title' => $this->l('Enabled'),
                'align' => 'center',
                'type' => 'bool',
                'active' => 'status'
                ),
            'start_date' => array(
                'title' => $this->module->l('Start'),
                'type' => 'date',
                'align' => 'text-right',
            ),
            'expiry_date' => array(
                'title' => $this->module->l('End'),
                'type' => 'date',
                'align' => 'text-right',
            ),
        );

        $this->bulk_actions = array(
            'delete' => array(
                'text' => $this->l('Delete selected'),
                'confirm' => $this->l('Delete selected items?')
                )
            );
    }

    public function renderList()
    {
        $this->addRowAction('edit');
        $this->addRowAction('delete');
        return parent::renderList();
    }

    public function setMedia($isNewTheme = false)
    {
        parent::setMedia($isNewTheme);
        $this->addJqueryUI(array('ui.datepicker'));
    }
    
    public function renderForm()
    {
        $obj = $this->loadObject(true);
        $type = (Tools::version_compare(_PS_VERSION_, '1.7.0.0', '<') == true) ? 'radio' : 'switch';
        $this->fields_form = array(
            'tinymce' => true,
            'legend' => array(
                'title' => $this->l('Add/Edit Restricted Area'),
                'icon' => 'icon-eye-slash'
            ),
            'input' => array(
                array(
                    'type' => 'text',
                    'label' => $this->l('Title'),
                    'name' => 'title',
                    'lang' => false,
                    'required' => false,
                    'hint' => $this->l('Invalid characters:').' <>;=#{}',
                    'desc' => $this->l('For back office use only.'),
                ),
                array(
                    'type' => $type,
                    'label' => $this->l('Status'),
                    'name' => 'active',
                    'required' => true,
                    'is_bool' => true,
                    'values' => array(
                        array(
                            'id' => 'active_on',
                            'value' => 1,
                            'label' => $this->l('Enabled')
                        ),
                        array(
                            'id' => 'active_off',
                            'value' => 0,
                            'label' => $this->l('Disabled')
                        )
                    )
                ),
                array(
                    'type' => 'group',
                    'label' => $this->l('Customer Group access'),
                    'name' => 'groupBox',
                    'required' => true,
                    'values' => Group::getGroups($this->context->language->id),
                    'hint' => $this->l('Mark all of the customer groups which you would like to have access.'),
                    'desc' => $this->l('Mark all of the customer groups which you would like to have access.'),
                ),
                array(
                    'type' => 'radio',
                    'label' => $this->l('Restriction Action'),
                    'name' => 'rule_type',
                    'required' => true,
                    'is_bool' => true,
                    'values' => array(
                        array(
                            'id' => 'active_on',
                            'value' => 1,
                            'label' => $this->l('Redirect to URL')
                        ),
                        array(
                            'id' => 'active_off',
                            'value' => 0,
                            'label' => $this->l('Show Message')
                        )
                    )
                ),
                array(
                    'type' => 'textarea',
                    'label' => $this->l('Message OR Redirect URL'),
                    'name' => 'value',
                    'lang' => true,
                    'autoload_rte' => true,
                    'required' => true,
                    'desc' => $this->l('If Restriction Action is URL than please simply write complete URL like https://www.prestashop.com/en/about-us'),
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('CMS Pages to Restrict'),
                    'name' => 'cms',
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Categories to Restrict'),
                    'name' => 'categories',
                ),
                array(
                    'type' => $type,
                    'label' => $this->l('Restrict Category Products'),
                    'name' => 'category_products',
                    'required' => false,
                    'is_bool' => true,
                    'values' => array(
                        array(
                            'id' => 'active_on',
                            'value' => 1,
                            'label' => $this->l('Enabled')
                        ),
                        array(
                            'id' => 'active_off',
                            'value' => 0,
                            'label' => $this->l('Disabled')
                        )
                    )
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Products to Restrict'),
                    'name' => 'products',
                ),
                array(
                    'type' => 'datetime',
                    'label' => $this->l('Restriction Starts'),
                    'name' => 'start_date',
                    'filter_key' => 'a!start_date'
                ),
                array(
                    'type' => 'datetime',
                    'label' => $this->l('Restriction Ends'),
                    'name' => 'expiry_date',
                    'filter_key' => 'a!expiry_date'
                ),
            ),
            'submit' => array(
                'title' => $this->l('Save'),
                ),
        );
        if (Shop::isFeatureActive()) {
            $this->fields_form['input'][] = array(
                'type' => 'shop',
                'label' => $this->l('Shop association'),
                'name' => 'checkBoxShopAsso',
            );
        }
        $products = array();
        $cms_pages = CMS::listCms();
        $categories = Category::getSimpleCategories($this->context->language->id);
        $url = $this->context->link->getAdminLink('AdminRestrictCustomerGroup', true);
        $ps_17 = (Tools::version_compare(_PS_VERSION_, '1.7.0.0', '>=') == true) ? 1 : 0;
        if ($obj->id) {
            if (!empty($cms_pages)) {
                foreach ($cms_pages as &$cms) {
                    $cms['checked'] = (int)$obj->needleCheck('restrictcustomergroup_cms', 'id_cms', $cms['id_cms'], $obj->id);
                }
            }
            if (!empty($categories)) {
                foreach ($categories as &$category) {
                    $category['checked'] = (int)$obj->needleCheck('restrictcustomergroup_categories', 'id_category', $category['id_category'], $obj->id);
                }
            }
            $products = $obj->getProductsCollection($obj->id);
            if (!empty($products) && is_array($products)) {
                foreach ($products as &$product) {
                    $product = new Product((int)$product['id_product'], true, (int)$this->context->language->id);
                    $product->id_product_attribute = (int)Product::getDefaultAttribute($product->id) > 0 ? (int)Product::getDefaultAttribute($product->id) : 0;
                    $_cover = ((int)$product->id_product_attribute > 0) ? Product::getCombinationImageById((int)$product->id_product_attribute, $this->context->language->id) : Product::getCover($product->id);
                    if (!is_array($_cover)) {
                       $_cover = Product::getCover($product->id);
                    }
                    $product->id_image = $_cover['id_image'];
                }
            }
            $groups = Group::getGroups($this->context->language->id);
            foreach ($groups as $group) {
                $groups_ids = $obj->needleCheck('restrictcustomergroup_group', 'id_group', $group['id_group'], $obj->id);
                $this->fields_value['groupBox_'.$group['id_group']] = $groups_ids;
            }
        }
        else {
            $groups = Group::getGroups($this->context->language->id);
            foreach ($groups as $group) {
                $this->fields_value['groupBox_'.$group['id_group']] = 0;
            }
        }
        $this->context->smarty->assign(array(
            'ps_17' => (int)$ps_17,
            'cms_pages' => $cms_pages,
            'categories' => $categories,
            'products' => $products,
            'action_url' => $url.'&action=getSearchProducts&forceJson=1&disableCombination=1&exclude_packs=0&excludeVirtuals=0&limit=20',
        ));
        return parent::renderForm();
    }
    
    public function init()
	{
		parent::init();
		Shop::addTableAssociation($this->table, array('type' => 'shop'));
		if (Shop::getContext() == Shop::CONTEXT_SHOP)
			$this->_join .= ' LEFT JOIN `'._DB_PREFIX_.'restrictcustomergroup_shop` sa ON (a.`id_restrictcustomergroup` = sa.`id_restrictcustomergroup` AND sa.id_shop = '.(int)$this->context->shop->id.') ';
		if (Shop::getContext() == Shop::CONTEXT_SHOP && Shop::isFeatureActive())
			$this->_where = ' AND sa.`id_shop` = '.(int)Context::getContext()->shop->id;
	}
    
    public function initProcess()
    {
        $action = Tools::getValue('action');
        if (Tools::isSubmit('submitAddrestrictcustomergroup')) {
            $groups = Tools::getValue('groupBox');
            $categories = Tools::getValue('category');
            $products = Tools::getValue('related_products');
            $cms = Tools::getValue('cms');
            if (empty($groups)) {
                $this->errors[] = $this->l('You must select customer group(s).');
            }
            elseif(empty($cms) && empty($categories) && empty($products)) {
                $this->errors[] = $this->l('You must select any category, cms page OR product to privatize.');
            }
        }
        if ($action == 'getSearchProducts') {
            $this->getSearchProducts();
            die();
        }
        return parent::initProcess();
    }
    
    public function postProcess()
    {
        parent::postProcess();
        $obj = $this->loadObject(true);
        $groups = Tools::getValue('groupBox');
        $categories = Tools::getValue('category');
        $products = Tools::getValue('related_products');
        $cms = Tools::getValue('cms');
        if ($obj->id && Tools::isSubmit('submitAddrestrictcustomergroup')) {
            $obj->dumpCurrentData($obj->id);
            if (!empty($groups)) {
                $obj->populateTable('restrictcustomergroup_group', 'id_group', $obj->id, $groups);
            }
            if (!empty($categories)) {
                $obj->populateTable('restrictcustomergroup_categories', 'id_category', $obj->id, $categories);
            }
            if (!empty($products)) {
                $obj->populateTable('restrictcustomergroup_products', 'id_product', $obj->id, $products);
            }
            if (!empty($cms)) {
                $obj->populateTable('restrictcustomergroup_cms', 'id_cms', $obj->id, $cms);
            }
        }
    }
    
    protected function getSearchProducts()
    {
        $query = Tools::getValue('q', false);
        if (!$query || $query == '' || Tools::strlen($query) < 1) {
            exit(json_encode($this->l('Found Nothing.')));
        }

        /*
         * In the SQL request the "q" param is used entirely to match result in database.
         * In this way if string:"(ref : #ref_pattern#)" is displayed on the return list,
         * they are no return values just because string:"(ref : #ref_pattern#)"
         * is not write in the name field of the product.
         * So the ref pattern will be cut for the search request.
         */
        if ($pos = strpos($query, ' (ref:')) {
            $query = Tools::substr($query, 0, $pos);
        }

        $excludeIds = Tools::getValue('excludeIds', false);
        if ($excludeIds && $excludeIds != 'NaN') {
            $excludeIds = implode(',', array_map('intval', explode(',', $excludeIds)));
        } else {
            $excludeIds = '';
        }

        // Excluding downloadable products from packs because download from pack is not supported
        $forceJson = Tools::getValue('forceJson', false);
        $disableCombination = Tools::getValue('disableCombination', false);
        $excludeVirtuals = (bool)Tools::getValue('excludeVirtuals', true);
        $exclude_packs = (bool)Tools::getValue('exclude_packs', true);

        $context = Context::getContext();

        $sql = 'SELECT p.`id_product`, pl.`link_rewrite`, p.`reference`, pl.`name`, image_shop.`id_image` id_image, il.`legend`, p.`cache_default_attribute`
                FROM `'._DB_PREFIX_.'product` p
                '.Shop::addSqlAssociation('product', 'p').'
                LEFT JOIN `'._DB_PREFIX_.'product_lang` pl ON (pl.id_product = p.id_product AND pl.id_lang = '.(int)$context->language->id.Shop::addSqlRestrictionOnLang('pl').')
                LEFT JOIN `'._DB_PREFIX_.'image_shop` image_shop
                    ON (image_shop.`id_product` = p.`id_product` AND image_shop.cover=1 AND image_shop.id_shop='.(int)$context->shop->id.')
                LEFT JOIN `'._DB_PREFIX_.'image_lang` il ON (image_shop.`id_image` = il.`id_image` AND il.`id_lang` = '.(int)$context->language->id.')
                WHERE (pl.name LIKE \'%'.pSQL($query).'%\' OR p.reference LIKE \'%'.pSQL($query).'%\')'.
                (!empty($excludeIds) ? ' AND p.id_product NOT IN ('.$excludeIds.') ' : ' ').
                ($excludeVirtuals ? 'AND NOT EXISTS (SELECT 1 FROM `'._DB_PREFIX_.'product_download` pd WHERE (pd.id_product = p.id_product))' : '').
                ($exclude_packs ? 'AND (p.cache_is_pack IS NULL OR p.cache_is_pack = 0)' : '').
                ' GROUP BY p.id_product';

        $items = Db::getInstance()->executeS($sql);
        if ($items && ($disableCombination ||$excludeIds)) {
            $results = array();
            foreach ($items as $item) {
                if (!$forceJson) {
                    $item['name'] = str_replace('|', '&#124;', $item['name']);
                    $results[] = trim($item['name']).(!empty($item['reference']) ? ' (ref: '.$item['reference'].')' : '').'|'.(int)$item['id_product'];
                } else {
                    $cover = Product::getCover($item['id_product']);
                    $results[] = array(
                        'id' => $item['id_product'],
                        'name' => $item['name'].(!empty($item['reference']) ? ' (ref: '.$item['reference'].')' : ''),
                        'ref' => (!empty($item['reference']) ? $item['reference'] : ''),
                        'image' => str_replace('http://', Tools::getShopProtocol(), $context->link->getImageLink($item['link_rewrite'], (($item['id_image'])?$item['id_image']:$cover['id_image']), $this->getFormatedName('home'))),
                    );
                }
            }

            if (!$forceJson) {
                echo implode("\n", $results);
            } else {
                echo json_encode($results);
            }
        } elseif ($items) {
            // packs
            $results = array();
            foreach ($items as $item) {
                // check if product have combination
                if (Combination::isFeatureActive() && $item['cache_default_attribute']) {
                    $sql = 'SELECT pa.`id_product_attribute`, pa.`reference`, ag.`id_attribute_group`, pai.`id_image`, agl.`name` AS group_name, al.`name` AS attribute_name,
                                a.`id_attribute`
                            FROM `'._DB_PREFIX_.'product_attribute` pa
                            '.Shop::addSqlAssociation('product_attribute', 'pa').'
                            LEFT JOIN `'._DB_PREFIX_.'product_attribute_combination` pac ON pac.`id_product_attribute` = pa.`id_product_attribute`
                            LEFT JOIN `'._DB_PREFIX_.'attribute` a ON a.`id_attribute` = pac.`id_attribute`
                            LEFT JOIN `'._DB_PREFIX_.'attribute_group` ag ON ag.`id_attribute_group` = a.`id_attribute_group`
                            LEFT JOIN `'._DB_PREFIX_.'attribute_lang` al ON (a.`id_attribute` = al.`id_attribute` AND al.`id_lang` = '.(int)$context->language->id.')
                            LEFT JOIN `'._DB_PREFIX_.'attribute_group_lang` agl ON (ag.`id_attribute_group` = agl.`id_attribute_group` AND agl.`id_lang` = '.(int)$context->language->id.')
                            LEFT JOIN `'._DB_PREFIX_.'product_attribute_image` pai ON pai.`id_product_attribute` = pa.`id_product_attribute`
                            WHERE pa.`id_product` = '.(int)$item['id_product'].'
                            GROUP BY pa.`id_product_attribute`, ag.`id_attribute_group`
                            ORDER BY pa.`id_product_attribute`';

                    $combinations = Db::getInstance()->executeS($sql);
                    if (!empty($combinations)) {
                        foreach ($combinations as $combination) {
                            $cover = Product::getCover($item['id_product']);
                            $results[$combination['id_product_attribute']]['id'] = $item['id_product'];
                            $results[$combination['id_product_attribute']]['id_product_attribute'] = $combination['id_product_attribute'];
                            !empty($results[$combination['id_product_attribute']]['name']) ? $results[$combination['id_product_attribute']]['name'] .= ' '.$combination['group_name'].'-'.$combination['attribute_name']
                            : $results[$combination['id_product_attribute']]['name'] = $item['name'].' '.$combination['group_name'].'-'.$combination['attribute_name'];
                            if (!empty($combination['reference'])) {
                                $results[$combination['id_product_attribute']]['ref'] = $combination['reference'];
                            } else {
                                $results[$combination['id_product_attribute']]['ref'] = !empty($item['reference']) ? $item['reference'] : '';
                            }
                            if (empty($results[$combination['id_product_attribute']]['image'])) {
                                $results[$combination['id_product_attribute']]['image'] = str_replace('http://', Tools::getShopProtocol(), $context->link->getImageLink($item['link_rewrite'], (($combination['id_image'])?$combination['id_image']:$cover['id_image']), $this->getFormatedName('home')));

                            }
                        }
                    } else {
                        $results[] = array(
                            'id' => $item['id_product'],
                            'name' => $item['name'],
                            'ref' => (!empty($item['reference']) ? $item['reference'] : ''),
                            'image' => str_replace('http://', Tools::getShopProtocol(), $context->link->getImageLink($item['link_rewrite'], $item['id_image'], $this->getFormatedName('home'))),
                        );
                    }
                } else {
                    $results[] = array(
                        'id' => $item['id_product'],
                        'name' => $item['name'],
                        'ref' => (!empty($item['reference']) ? $item['reference'] : ''),
                        'image' => str_replace('http://', Tools::getShopProtocol(), $context->link->getImageLink($item['link_rewrite'], $item['id_image'], $this->getFormatedName('home'))),
                    );
                }
            }
            echo json_encode(array_values($results));
        } else {
            echo json_encode(array());
        }
    }
    
    public function getFormatedName($name)
    {
        $theme_name = Context::getContext()->shop->theme_name;
        $name_without_theme_name = str_replace(array('_'.$theme_name, $theme_name.'_'), '', $name);
        //check if the theme name is already in $name if yes only return $name
        if (strstr($name, $theme_name) && ImageType::getByNameNType($name, 'products')) {
            return $name;
        } elseif (ImageType::getByNameNType($name_without_theme_name.'_'.$theme_name, 'products')) {
            return $name_without_theme_name.'_'.$theme_name;
        } elseif (ImageType::getByNameNType($theme_name.'_'.$name_without_theme_name, 'products')) {
            return $theme_name.'_'.$name_without_theme_name;
        } else {
            return $name_without_theme_name.'_default';
        }
    }
}
