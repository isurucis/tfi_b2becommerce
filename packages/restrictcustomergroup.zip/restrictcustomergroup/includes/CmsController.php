<?php
/**
 * 2007-2019 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/OSL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2019 PrestaShop SA
 * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

include_once(_PS_MODULE_DIR_.'restrictcustomergroup/classes/Rcg.php');
class CmsController extends CmsControllerCore
{
    public function initContent()
    {
        parent::initContent();
        $mod_status = Module::isEnabled('restrictcustomergroup');
        if ($mod_status == true) {
            $id = (int)Tools::getValue('id_cms');
            $rcg = new Rcg;
            $id_shop = (int)$this->context->shop->id;
            $id_lang = (int)$this->context->language->id;
            $get_count = (int)$rcg->countActiveRules($id_shop);
            $id_customer = (int)$this->context->customer->id;
            //if active rules exists
            if ($get_count > 0) {
                $flag = false;
                //if rule exist for current page - get_page_check will also return the rule ID
                $get_page_check = (int)$rcg->getRulesForPage('cms', $id, $id_shop);
                if ($get_page_check > 0) {
                    $rule_details = $rcg->getRuleDetails($get_page_check, $id_lang);
                    //Check group access for rule - if logged in
                    if ($id_customer > 0) {
                        $rule_customer_group = (int)$rcg->getCustomerQualification($get_page_check, $id_customer);
                        if ($rule_customer_group > 0) {
                            $flag = true;
                        }
                    }
                    elseif ($id_customer <= 0) {
                        $rule_visitors_group = $rcg->getVisitorQualification($get_page_check);
                        if ($rule_visitors_group > 0) {
                            $flag = true;
                        }
                    }
                    if (!empty($rule_details) && $flag == false) {
                        $msg = $rule_details['value'];
                        if ((int)$rule_details['rule_type'] <= 0) {
                            $msg = (empty($msg)) ? $this->l('You are not allowed to view this page.') : $msg;
                            $this->cms->content = $msg;
                        }
                    }
                }
            }
        }
    }
}
