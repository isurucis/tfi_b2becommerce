<?php
/**
* NOTICE OF LICENSE
*
* This source file is subject to the Open Software License (OSL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/osl-3.0.php
*
* @author    FMM Modules
* @copyright FMM Modules
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
* @category  FMM Modules
* @package   restrictcustomergroup
*/

include_once(_PS_MODULE_DIR_.'restrictcustomergroup/classes/Rcg.php');
class Category extends CategoryCore
{
    public function checkAccess($idCustomer)
    {
        $mod_status = Module::isEnabled('restrictcustomergroup');
        if ($mod_status == true) {
            $rcg = new Rcg;
            $this->context = Context::getContext();
            $id_shop = (int)$this->context->shop->id;
            $id_lang = (int)$this->context->language->id;
            $get_count = (int)$rcg->countActiveRules($id_shop);
            $id_customer = (int)$this->context->customer->id;
            if ($get_count > 0) {
                $flag = false;
                $get_page_check = (int)$rcg->getRulesForPage('category', $this->id, $id_shop);
                if ($get_page_check > 0) {
                    $rule_details = $rcg->getRuleDetails($get_page_check, $id_lang);
                    if ($id_customer > 0) {
                        $rule_customer_group = (int)$rcg->getCustomerQualification($get_page_check, $id_customer);
                        if ($rule_customer_group > 0) {
                            $flag = true;
                            return $this->getDefaultState($idCustomer);
                        }
                    }
                    elseif ($id_customer <= 0) {
                        $rule_visitors_group = $rcg->getVisitorQualification($get_page_check);
                        if ($rule_visitors_group > 0) {
                            $flag = true;
                            return $this->getDefaultState($idCustomer);
                        }
                    }
                    if (!empty($rule_details) && $flag == false) {
                        $msg = $rule_details['value'];
                        if ((int)$rule_details['rule_type'] > 0) {
                            if (!empty($msg)) {
                                $msg = Tools::safeOutput($msg);
                                if (Validate::isAbsoluteUrl($msg) == true) {
                                    Tools::redirectLink($msg);
                                }
                            }
                        }
                        else {
                            $msg = (empty($msg)) ? $this->l('You are not allowed to view this page.') : $msg;
                            header('HTTP/1.1 403 Forbidden');
                            header('Status: 403 Forbidden');
                            if (Tools::version_compare(_PS_VERSION_, '1.7.0.0', '>=') == true) {
                                return false;
                            }
                            else {
                                $this->customer_access = false;
                                return false;
                            }
                        }
                    }
                    else {
                        return $this->getDefaultState($idCustomer);
                    }
                }
                else {
                    return $this->getDefaultState($idCustomer);
                }
            }
            else {
                return $this->getDefaultState($idCustomer);
            }
        }
        else {
            return $this->getDefaultState($idCustomer);
        }
    }
    
    protected function getDefaultState($idCustomer)
    {
        $cacheId = 'Category::checkAccess_' . (int) $this->id . '-' . $idCustomer . (!$idCustomer ? '-' . (int) Group::getCurrent()->id : '');
        if (!Cache::isStored($cacheId)) {
            if (!$idCustomer) {
                $result = (bool) Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
                SELECT ctg.`id_group`
                FROM ' . _DB_PREFIX_ . 'category_group ctg
                WHERE ctg.`id_category` = ' . (int) $this->id . ' AND ctg.`id_group` = ' . (int) Group::getCurrent()->id);
            } else {
                $result = (bool) Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
                SELECT ctg.`id_group`
                FROM ' . _DB_PREFIX_ . 'category_group ctg
                INNER JOIN ' . _DB_PREFIX_ . 'customer_group cg on (cg.`id_group` = ctg.`id_group` AND cg.`id_customer` = ' . (int) $idCustomer . ')
                WHERE ctg.`id_category` = ' . (int) $this->id);
            }
            Cache::store($cacheId, $result);
            return $result;
        }
        return Cache::retrieve($cacheId);
    }
}
