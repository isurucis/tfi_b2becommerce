<?php
/**
* NOTICE OF LICENSE
*
* This source file is subject to the Open Software License (OSL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/osl-3.0.php
*
* @author    FMM Modules
* @copyright FMM Modules
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
* @category  FMM Modules
* @package   restrictcustomergroup
*/

include_once(_PS_MODULE_DIR_.'restrictcustomergroup/classes/Rcg.php');
class ProductController extends ProductControllerCore
{
    public function init()
    {
        parent::init();
        $id_product = (int) Tools::getValue('id_product');
        if ($id_product) {
            $this->product = new Product($id_product, true, $this->context->language->id, $this->context->shop->id);
        }
        $mod_status = Module::isEnabled('restrictcustomergroup');
        if ($mod_status == true) {
            $rcg = new Rcg;
            $id_shop = (int)$this->context->shop->id;
            $id_lang = (int)$this->context->language->id;
            $get_count = (int)$rcg->countActiveRules($id_shop);
            $id_customer = (int)$this->context->customer->id;
            if ($get_count > 0) {
                $flag = false;
                $category_data = Product::getProductCategories((int)$id_product);
                $get_page_check = (int)$rcg->getRulesForPage('product', $id_product, $id_shop);
                if ($get_page_check > 0) {
                    $rule_details = $rcg->getRuleDetails($get_page_check, $id_lang);
                    if ($id_customer > 0) {
                        $rule_customer_group = (int)$rcg->getCustomerQualification($get_page_check, $id_customer);
                        if ($rule_customer_group > 0) {
                            $flag = true;
                        }
                    }
                    elseif ($id_customer <= 0) {
                        $rule_visitors_group = $rcg->getVisitorQualification($get_page_check);
                        if ($rule_visitors_group > 0) {
                            $flag = true;
                            if ($flag) {
                                
                            }
                        }
                    }
                    if (!empty($rule_details) && $flag == false) {
                        $msg = $rule_details['value'];
                        if ((int)$rule_details['rule_type'] > 0) {
                            if (!empty($msg)) {
                                $msg = Tools::safeOutput($msg);
                                if (Validate::isAbsoluteUrl($msg) == true) {
                                    Tools::redirectLink($msg);
                                }
                            }
                        }
                        else {
                            $msg = (empty($msg)) ? $this->l('You are not allowed to view this page.') : $msg;
                            header('HTTP/1.1 403 Forbidden');
                            header('Status: 403 Forbidden');
                            if (Tools::version_compare(_PS_VERSION_, '1.7.0.0', '>=') == true) {
                                $this->errors[] = $msg;
                                $this->setTemplate('errors/forbidden');
                            }
                            else {
                                $this->errors[] = Tools::displayError($msg);
                                $this->customer_access = false;
                            }
                        }
                    }
                }
                elseif ($get_page_check <= 0 && !empty($category_data)) {
                    $crawled = false;
                        foreach ($category_data as $category) {
                            $get_page_check = (int)$rcg->getRulesForPageExtraParams('category', $category, $id_shop, true);
                            if ($get_page_check > 0 && !$crawled) {
                                $rule_details = $rcg->getRuleDetails($get_page_check, $id_lang);
                                if ($id_customer > 0) {
                                    $rule_customer_group = (int)$rcg->getCustomerQualification($get_page_check, $id_customer);
                                    if ($rule_customer_group > 0) {
                                        $flag = true;
                                    }
                                }
                                elseif ($id_customer <= 0) {
                                    $rule_visitors_group = $rcg->getVisitorQualification($get_page_check);
                                    if ($rule_visitors_group > 0) {
                                        $flag = true;
                                    }
                                }
                                if (!empty($rule_details) && $flag == false) {
                                    $crawled = true;
                                    $msg = $rule_details['value'];
                                    if ((int)$rule_details['rule_type'] > 0) {
                                        if (!empty($msg)) {
                                            $msg = Tools::safeOutput($msg);
                                            if (Validate::isAbsoluteUrl($msg) == true) {
                                                Tools::redirectLink($msg);
                                            }
                                        }
                                    }
                                    else {
                                        $msg = (empty($msg)) ? $this->l('You are not allowed to view this page.') : $msg;
                                        header('HTTP/1.1 403 Forbidden');
                                        header('Status: 403 Forbidden');
                                        if (Tools::version_compare(_PS_VERSION_, '1.7.0.0', '>=') == true) {
                                            $this->errors[] = $msg;
                                            $this->setTemplate('errors/forbidden');
                                        }
                                        else {
                                            $this->errors[] = Tools::displayError($msg);
                                            $this->customer_access = false;
                                        }
                                    }
                                }
                            }
                        }
                }
            }
        }
    }
}
