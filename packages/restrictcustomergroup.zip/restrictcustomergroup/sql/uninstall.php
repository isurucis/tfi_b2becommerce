<?php
/**
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    FME Modules
*  @copyright © 2019 FME Modules
*  @license   http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

$sql = array();

$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'restrictcustomergroup`';

$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'restrictcustomergroup_group`';

$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'restrictcustomergroup_customer`';

$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'restrictcustomergroup_shop`';

$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'restrictcustomergroup_lang`';

$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'restrictcustomergroup_categories`';

$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'restrictcustomergroup_products`';

$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'restrictcustomergroup_cms`';

foreach ($sql as $query) {
    if (Db::getInstance()->execute($query) == false) {
        return false;
    }
}
