<?php
/**
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    FME Modules
*  @copyright © 2019 FME Modules
*  @license   http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

$sql = array();

$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'restrictcustomergroup` (
        `id_restrictcustomergroup` int(11) NOT NULL auto_increment,
        `title` varchar(255) default NULL,
        `rule_type` tinyint(1) default \'0\',
        `active` tinyint(1) default \'0\',
        `category_products` tinyint(1) default \'0\',
        `start_date` datetime default NULL,
        `expiry_date` datetime default NULL,
        PRIMARY KEY (`id_restrictcustomergroup`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'restrictcustomergroup_group` (
        `id_restrictcustomergroup` int(10) NOT NULL,
        `id_group` int(10) NOT NULL,
        PRIMARY KEY (`id_restrictcustomergroup`, `id_group`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8;';
        
$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'restrictcustomergroup_customer` (
        `id_restrictcustomergroup` int(10) NOT NULL,
        `id_customer` int(10) NOT NULL,
        PRIMARY KEY (`id_restrictcustomergroup`, `id_customer`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8;';
        
$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'restrictcustomergroup_shop` (
        `id_restrictcustomergroup` int(10) NOT NULL,
        `id_shop` int(10) NOT NULL,
        PRIMARY KEY (`id_restrictcustomergroup`, `id_shop`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'restrictcustomergroup_lang` (
        `id_restrictcustomergroup` int(10) NOT NULL,
        `id_lang` int(10) NOT NULL,
        `value` text,
        PRIMARY KEY (`id_restrictcustomergroup`, `id_lang`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'restrictcustomergroup_categories` (
        `id_restrictcustomergroup` int(10) NOT NULL,
        `id_category` int(10) NOT NULL,
        PRIMARY KEY (`id_restrictcustomergroup`, `id_category`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8;';
        
$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'restrictcustomergroup_products` (
        `id_restrictcustomergroup` int(10) NOT NULL,
        `id_product` int(10) NOT NULL,
        PRIMARY KEY (`id_restrictcustomergroup`, `id_product`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8;';
        
$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'restrictcustomergroup_cms` (
        `id_restrictcustomergroup` int(10) NOT NULL,
        `id_cms` int(10) NOT NULL,
        PRIMARY KEY (`id_restrictcustomergroup`, `id_cms`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8;';

foreach ($sql as $query) {
    if (Db::getInstance()->execute($query) == false) {
        return false;
    }
}
