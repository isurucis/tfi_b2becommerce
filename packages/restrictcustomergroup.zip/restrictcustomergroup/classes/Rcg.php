<?php
/**
* NOTICE OF LICENSE
*
* This source file is subject to the Open Software License (OSL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/osl-3.0.php
*
* @author    FMM Modules
* @copyright FMM Modules
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
* @category  FMM Modules
* @package   productlabelsandstickers
*/

class Rcg extends ObjectModel {
	public $title;
	public $active;
	public $start_date;
	public $expiry_date;
	public $rule_type;
	public $value;
	public $category_products;
	
	public static $definition = array(
		'table' => 'restrictcustomergroup',
		'primary' => 'id_restrictcustomergroup',
		'multilang' => true,
		'fields' => array(
			'title' => array('type' => self::TYPE_STRING, 'validate' => 'isString', 'lang' => false, 'required' => false),
			'active' => array('type' => self::TYPE_BOOL),
			'rule_type' => array('type' => self::TYPE_BOOL),
			'start_date' => array('type' => self::TYPE_DATE, 'validate' => 'isDateFormat', 'required' => false),
			'expiry_date' => array('type' => self::TYPE_DATE, 'validate' => 'isDateFormat', 'required' => false),
			'category_products' => array('type' => self::TYPE_BOOL, 'required' => false),
			 /* Lang fields */
			'value' => array('type' => self::TYPE_HTML, 'lang' => true, 'validate' => 'isCleanHtml'),
		),
	);
	
	public static function populateTable($table, $key, $id, $raw)
    {
		if (is_array($raw)) {
			foreach ($raw as $row) {
				Db::getInstance()->insert($table,
					array(
						'id_restrictcustomergroup' => (int)$id,
						$key => $row)
					);
			}
		}
        $last_id = (int)Db::getInstance()->Insert_ID();
        return $last_id;
    }
	
	public static function needleCheck($table, $key, $id_key, $id_obj)
    {
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('SELECT `id_restrictcustomergroup`
            FROM `'._DB_PREFIX_.$table.'`
            WHERE `'.pSQL($key).'` = '.(int)$id_key.'
			AND `id_restrictcustomergroup` = '.(int)$id_obj);
    }
	
	public static function getProductsCollection($id)
    {
		$sql = new DbQuery();
        $sql->select('`id_product`');
        $sql->from('restrictcustomergroup_products');
		$sql->where('`id_restrictcustomergroup` = '.(int)$id);
		return Db::getInstance()->executeS($sql);
	}
	
	public static function dumpCurrentData($id)
    {
		Db::getInstance()->delete('restrictcustomergroup_group', 'id_restrictcustomergroup = '.(int)$id);
		Db::getInstance()->delete('restrictcustomergroup_categories', 'id_restrictcustomergroup = '.(int)$id);
		Db::getInstance()->delete('restrictcustomergroup_products', 'id_restrictcustomergroup = '.(int)$id);
		Db::getInstance()->delete('restrictcustomergroup_cms', 'id_restrictcustomergroup = '.(int)$id);
	}
	
	public static function countActiveRules($id_shop)
    {
		$now = date('Y-m-d H:i:s');
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('SELECT COUNT(a.`id_restrictcustomergroup`)
            FROM `'._DB_PREFIX_.'restrictcustomergroup` a
			LEFT JOIN `'._DB_PREFIX_.'restrictcustomergroup_shop` b
			ON (a.`id_restrictcustomergroup` = b.`id_restrictcustomergroup`)
            WHERE a.`active` > 0
			AND b.`id_shop` = '.(int)$id_shop.'
			AND
            (
                (a.`start_date` = \'0000-00-00 00:00:00\' OR \''.pSQL($now).'\' >= a.`start_date`)
                AND
                (a.`expiry_date` = \'0000-00-00 00:00:00\' OR \''.pSQL($now).'\' <= a.`expiry_date`)
            )');
    }
	
	public static function getRulesForPage($page, $id, $id_shop)
    {
		if ($page == 'product') {
			$page_refil = 'products';
		}
		elseif ($page == 'category') {
			$page_refil = 'categories';
		}
		else {
			$page_refil = 'cms';
		}
		$now = date('Y-m-d H:i:s');
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('SELECT c.`id_restrictcustomergroup`
            FROM `'._DB_PREFIX_.'restrictcustomergroup` a
			LEFT JOIN `'._DB_PREFIX_.'restrictcustomergroup_shop` b
			ON (a.`id_restrictcustomergroup` = b.`id_restrictcustomergroup`)
			LEFT JOIN `'._DB_PREFIX_.'restrictcustomergroup_'.pSQL($page_refil).'` c
			ON (a.`id_restrictcustomergroup` = c.`id_restrictcustomergroup` AND c.`id_'.pSQL($page).'` = '.(int)$id.')
            WHERE a.`active` > 0
			AND b.`id_shop` = '.(int)$id_shop.'
			AND
            (
                (a.`start_date` = \'0000-00-00 00:00:00\' OR \''.pSQL($now).'\' >= a.`start_date`)
                AND
                (a.`expiry_date` = \'0000-00-00 00:00:00\' OR \''.pSQL($now).'\' <= a.`expiry_date`)
            )
			AND c.`id_restrictcustomergroup` > 0');
    }
	
	public static function getRuleDetails($id, $id_lang)
    {
		$sql = new DbQuery();
        $sql->select('rcg.`rule_type`, rcgl.`value`');
        $sql->from('restrictcustomergroup', 'rcg');
		$sql->leftJoin('restrictcustomergroup_lang', 'rcgl', 'rcg.`id_restrictcustomergroup` = rcgl.`id_restrictcustomergroup` AND rcgl.`id_lang` = '.(int)$id_lang);
		$sql->where('rcg.`id_restrictcustomergroup` = '.(int)$id);
		$return = Db::getInstance()->executeS($sql);
		$return = end($return);
		return $return;
	}
	
	public static function getCustomerQualification($id, $id_customer)
    {
		$groups = Customer::getGroupsStatic($id_customer);
		return Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('SELECT COUNT(`id_restrictcustomergroup`)
        FROM `'._DB_PREFIX_.'restrictcustomergroup_group`
		WHERE `id_group` IN ('.implode(',', array_map('intval', $groups)).')
		AND`id_restrictcustomergroup` = '.(int)$id);
	}
	
	public static function getVisitorQualification($id)
    {
		$id_visitor_group = (Tools::version_compare(_PS_VERSION_, '1.7.0.0', '<') == true) ? Configuration::get('PS_UNIDENTIFIED_GROUP') : 1;
		return Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('SELECT COUNT(`id_restrictcustomergroup`)
        FROM `'._DB_PREFIX_.'restrictcustomergroup_group`
		WHERE `id_group` = '.(int)$id_visitor_group.'
		AND`id_restrictcustomergroup` = '.(int)$id);
	}
	
	public static function getRulesForPageExtraParams($page, $id, $id_shop, $category_childs)
    {
		if ($page == 'product') {
			$page_refil = 'products';
		}
		elseif ($page == 'category') {
			$page_refil = 'categories';
		}
		else {
			$page_refil = 'cms';
		}
		$now = date('Y-m-d H:i:s');
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('SELECT c.`id_restrictcustomergroup`
            FROM `'._DB_PREFIX_.'restrictcustomergroup` a
			LEFT JOIN `'._DB_PREFIX_.'restrictcustomergroup_shop` b
			ON (a.`id_restrictcustomergroup` = b.`id_restrictcustomergroup`)
			LEFT JOIN `'._DB_PREFIX_.'restrictcustomergroup_'.pSQL($page_refil).'` c
			ON (a.`id_restrictcustomergroup` = c.`id_restrictcustomergroup` AND c.`id_'.pSQL($page).'` = '.(int)$id.')
            WHERE a.`active` > 0
			AND a.`category_products` > 0
			AND b.`id_shop` = '.(int)$id_shop.'
			AND
            (
                (a.`start_date` = \'0000-00-00 00:00:00\' OR \''.pSQL($now).'\' >= a.`start_date`)
                AND
                (a.`expiry_date` = \'0000-00-00 00:00:00\' OR \''.pSQL($now).'\' <= a.`expiry_date`)
            ) AND c.`id_restrictcustomergroup` > 0');
    }
}