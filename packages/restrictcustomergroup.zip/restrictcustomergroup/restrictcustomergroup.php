<?php
/**
* Restrict Customer Groups
*
* NOTICE OF LICENSE
*
* This source file is subject to the Open Software License (OSL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/osl-3.0.php
*
* @author    FMM Modules
* @copyright Copyright 2020 © FMM Modules All right reserved
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
* @category  front_office_features
* @package   restrictcustomergroup
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

include_once(dirname(__FILE__).'/classes/Rcg.php');
class RestrictCustomerGroup extends Module
{
    public function __construct()
    {
        $this->name = 'restrictcustomergroup';
        $this->tab = 'administration';
        $this->version = '1.2.0';
        $this->author = 'FMM Modules';
        $this->bootstrap = true;
        $this->module_key = '95663a6651f7c77d306e6d681ae1e7f5';
        $this->author_address = '0xcC5e76A6182fa47eD831E43d80Cd0985a14BB095';
        $this->ps_versions_compliancy = array(
            'min' => '1.6.0.14',
        );
        parent::__construct();
        
        $this->displayName = $this->l('Restrict Customer Groups');
        $this->description = $this->l('Allow a group of customers to shop for specific categories/products/cms pages.');
    }

    public function install()
    {
        include(dirname(__FILE__).'/sql/install.php');
        return (parent::install()
                && $this->addTab()
                && $this->registerHook('header')
                && $this->registerHook('actionCartSave')
                && $this->registerHook('displayRcg')
                && $this->moveFiles());
    }

    public function uninstall()
    {
        include(dirname(__FILE__).'/sql/uninstall.php');
        return ($this->removeTab() && parent::uninstall() && $this->delFiles());
    }

    public function moveFiles()
    {
        if (Tools::version_compare(_PS_VERSION_, '1.7.0.0', '<') == true) {
            Tools::copy(_PS_MODULE_DIR_.'restrictcustomergroup/includes/CmsController.php', _PS_OVERRIDE_DIR_.'controllers/front/CmsController.php');
            if (file_exists(_PS_CACHE_DIR_.'class_index.php')) {
                rename(_PS_CACHE_DIR_.'class_index.php', _PS_CACHE_DIR_.'class_index'.rand(pow(10, 3 - 1), pow(10, 3) - 1).'.php');
            }
        }
        return true;
    }
    
    public function delFiles()
    {
        if (Tools::version_compare(_PS_VERSION_, '1.7.0.0', '<') == true) {
            unlink(_PS_OVERRIDE_DIR_.'controllers/front/CmsController.php');
        }
        return true;
    }
    
    private function addTab()
    {
        $tab = new Tab();
        $tab->class_name = 'AdminRestrictCustomerGroups';
        $tab->id_parent = -1;
        $tab->module = $this->name;
        $tab->name[(int)(Configuration::get('PS_LANG_DEFAULT'))] = $this->displayName;
        $tab->add();

        $subtab = new Tab();
        $subtab->class_name = 'AdminRestrictCustomerGroup';
        $subtab->id_parent = Tab::getIdFromClassName('AdminRestrictCustomerGroups');
        $subtab->module = $this->name;
        $subtab->name[(int)Configuration::get('PS_LANG_DEFAULT')] = $this->displayName;
        if (true === Tools::version_compare(_PS_VERSION_, '1.7.0.0', '>=')) {
            $subtab->icon = 'pan_tool';
        }
        $subtab->add();
        return true;
    }

    private function removeTab()
    {
        $res = true;
        $id_tab = Tab::getIdFromClassName('AdminRestrictCustomerGroups');
        if ($id_tab != 0) {
            $tab = new Tab($id_tab);
            $res &= $tab->delete();
        }

        $id_tab1 = Tab::getIdFromClassName('AdminRestrictCustomerGroup');
        if ($id_tab1 != 0) {
            $tab = new Tab($id_tab1);
            $res &= $tab->delete();
        }
        return $res;
    }

    public function getContent()
    {
        $btn_link = $this->context->link->getAdminLink('AdminRestrictCustomerGroup');
        $this->context->smarty->assign('btn_link', $btn_link);
        $this->html = Module::getInstanceByName('b2becommerce')->getB2bMenu();
        $this->html .= $this->display(__FILE__, 'views/templates/hook/info.tpl');
        $this->button = $this->display(__FILE__, 'views/templates/hook/button.tpl');
        return $this->postProcess().$this->html.$this->button.$this->renderForm();
    }

    public function renderForm()
    {
        $type = (Tools::version_compare(_PS_VERSION_, '1.6.0.0', '>=') == true) ? 'switch' : 'radio';
        $ps_v = (Tools::version_compare(_PS_VERSION_, '1.7.0.0', '>=') == true) ? 1 : 0;
        $force_ssl = Configuration::get('PS_SSL_ENABLED');
        $base = ($force_ssl > 0) ? _PS_BASE_URL_SSL_.__PS_BASE_URI__ : _PS_BASE_URL_.__PS_BASE_URI__;
        $path_img = ($ps_v > 0) ? $base.'modules/'.$this->name.'/views/img/help.png' : $base.'modules/'.$this->name.'/views/img/help_16.png';
        $path_tpl = ($ps_v > 0) ? '/themes/YOUR_THEME/templates/catalog/_partials/miniatures/product.tpl' : '/themes/YOUR_THEME/product-list.tpl';
        $status_admin = array(
            'type' => $type,
            'label' => $this->l('Hide Restricted Products?'),
            'name' => 'RCG_PRODUCTS_VISIBLE',
            'required' => false,
            'class' => 't',
            'is_bool' => true,
            'values' => array(
                array(
                    'id' => 'rcg_on',
                    'value' => 1,
                    'label' => $this->l('Yes')
                    ),
                array(
                    'id' => 'rcg_off',
                    'value' => 0,
                    'label' => $this->l('No')
                    )
                ),
            );
        
        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Settings'),
                    'icon' => 'icon-cogs'
                ),
                'input' => array(
                    $status_admin,
                ),
                'description' => '<p>In case you want to hide products, please add this hook <b>{hook h=\'displayRcg\' product=$product}</b> in <u>div</u>
                tag you already have in file '.$path_tpl.'
                like shown in image: <img src="'.$path_img.'" /></p>',
                'submit' => array(
                    'title' => $this->l('Save')
                )
            ),
        );

        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $helper->module = $this;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submit'.$this->name;
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'uri' => $this->getPathUri(),
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );
        return $helper->generateForm(array($fields_form));
	}
    
    public function getConfigFieldsValues()
    {
        $fields = array();
        $fields['RCG_PRODUCTS_VISIBLE'] = (int)Configuration::get('RCG_PRODUCTS_VISIBLE');
        return $fields;
    }
	
	public function postProcess()
    {
        if (Tools::isSubmit('submit'.$this->name)) {
            Configuration::updateValue('RCG_PRODUCTS_VISIBLE', (int)Tools::getValue('RCG_PRODUCTS_VISIBLE'));
            return $this->displayConfirmation($this->l('The settings have been updated.'));
        }
        return '';
    }
    
    public function hookHeader()
    {
        $rcg = new Rcg;
        $id_shop = (int)$this->context->shop->id;
        $id_lang = (int)$this->context->language->id;
        $get_count = (int)$rcg->countActiveRules($id_shop);
        $page_name = Dispatcher::getInstance()->getController();
        $id_customer = (int)$this->context->customer->id;
        //if active rules exists
        if ($get_count > 0 && $page_name == 'cms') {
            $flag = false;
            $id = (int)Tools::getValue('id_product');
            $id = ($id <= 0) ? (int)Tools::getValue('id_category') : $id;
            $id = ($id <= 0) ? (int)Tools::getValue('id_cms') : $id;
            //if rule exist for current page - get_page_check will also return the rule ID
            $get_page_check = (int)$rcg->getRulesForPage($page_name, $id, $id_shop);
            if ($get_page_check > 0) {
                $rule_details = $rcg->getRuleDetails($get_page_check, $id_lang);
                //Check group access for rule - if logged in
                if ($id_customer > 0) {
                    $rule_customer_group = (int)$rcg->getCustomerQualification($get_page_check, $id_customer);
                    if ($rule_customer_group > 0) {
                        $flag = true;
                    }
                }
                elseif ($id_customer <= 0) {
                    $rule_visitors_group = $rcg->getVisitorQualification($get_page_check);
                    if ($rule_visitors_group > 0) {
                        $flag = true;
                    }
                }
                if ($page_name == 'cms' && !empty($rule_details) && $flag == false) {
                    $msg = $rule_details['value'];
                    if ((int)$rule_details['rule_type'] > 0) {
                        if (!empty($msg)) {
                            $msg = Tools::safeOutput($msg);
                            if (Validate::isAbsoluteUrl($msg) == true) {
                                Tools::redirectLink($msg);
                            }
                        }
                    }
                    else {
                        $msg = (empty($msg)) ? $this->l('You are not allowed to view this page.') : $msg;
                        $cms = new CMS($id, $id_lang);
                        $cmsVar = array('content' => $msg,
                                        'meta_title' => $cms->meta_title,
                                        'id' => $cms->id);
                        $this->context->smarty->assign(array(
                            'cms' => $cmsVar,
                        ));
                    }
                }
            }
        }
    }
    
    public function hookActionCartSave($params)
    {
        $mod_status = Module::isEnabled('restrictcustomergroup');
        if (isset($params['cart']) && $mod_status == true) {
            $cart = $params['cart'];
            $rcg = new Rcg;
            $id_shop = (int)$this->context->shop->id;
            $id_lang = (int)$this->context->language->id;
            $get_count = (int)$rcg->countActiveRules($id_shop);
            $id_customer = (int)$this->context->customer->id;
            $cart_product = $cart->getLastProduct();
            if (!empty($cart_product) && isset($cart_product['id_product']) && $get_count > 0) {
                $id_product = $cart_product['id_product'];
                $flag = false;
                $category_data = Product::getProductCategories((int)$id_product);
                $get_page_check = (int)$rcg->getRulesForPage('product', $id_product, $id_shop);
                if ($get_page_check > 0) {
                    $rule_details = $rcg->getRuleDetails($get_page_check, $id_lang);
                    if ($id_customer > 0) {
                        $rule_customer_group = (int)$rcg->getCustomerQualification($get_page_check, $id_customer);
                        if ($rule_customer_group > 0) {
                            $flag = true;
                        }
                    }
                    elseif ($id_customer <= 0) {
                        $rule_visitors_group = $rcg->getVisitorQualification($get_page_check);
                        if ($rule_visitors_group > 0) {
                            $flag = true;
                        }
                    }
                    if (!empty($rule_details) && $flag == false) {
                        //we are here means the user is not permitted to add this product in cart
                        $this->deleteProduct($id_product, $cart->id);
                    }
                }
                elseif ($get_page_check <= 0 && !empty($category_data)) {
                    $crawled = false;
                    foreach ($category_data as $category) {
                        $get_page_check = (int)$rcg->getRulesForPageExtraParams('category', $category, $id_shop, true);
                        if ($get_page_check > 0 && !$crawled) {
                            $rule_details = $rcg->getRuleDetails($get_page_check, $id_lang);
                            if ($id_customer > 0) {
                                $rule_customer_group = (int)$rcg->getCustomerQualification($get_page_check, $id_customer);
                                if ($rule_customer_group > 0) {
                                    $flag = true;
                                }
                            }
                            elseif ($id_customer <= 0) {
                                $rule_visitors_group = $rcg->getVisitorQualification($get_page_check);
                                if ($rule_visitors_group > 0) {
                                    $flag = true;
                                }
                            }
                            if (!empty($rule_details) && $flag == false) {
                                $this->deleteProduct($id_product, $cart->id);
                            }
                        }
                    }
                }
            }
        }
    }
    
    private function deleteProduct($id_product, $id_cart)
    {
        return Db::getInstance()->execute('
        DELETE FROM `' . _DB_PREFIX_ . 'cart_product`
        WHERE `id_product` = ' . (int) $id_product . '
        AND `id_cart` = ' . (int) $id_cart);
    }
    
    public function crawlProductRestriction($id_product)
    {
        $rcg = new Rcg;
        $id_shop = (int)$this->context->shop->id;
        $get_count = (int)$rcg->countActiveRules($id_shop);
        $id_customer = (int)$this->context->customer->id;
        $flag = true;
        $category_data = Product::getProductCategories((int)$id_product);
        $get_page_check = (int)$rcg->getRulesForPage('product', $id_product, $id_shop);

        if ($get_page_check > 0) {
            if ($id_customer > 0) {
                $rule_customer_group = (int)$rcg->getCustomerQualification($get_page_check, $id_customer);
                if ($rule_customer_group > 0) {
                    $flag = false;
                }
            }
            elseif ($id_customer <= 0) {
                $rule_visitors_group = $rcg->getVisitorQualification($get_page_check);
                if ($rule_visitors_group > 0) {
                    $flag = false;
                }
            }
            if ($flag == true) {
                $flag = false;
                return (int)$flag;
            }
            else {
                $flag = true;
                return (int)$flag;
            }
        }
        elseif ($get_page_check <= 0 && !empty($category_data)) {
            $crawled = false;
            foreach ($category_data as $category) {
                $get_page_check = (int)$rcg->getRulesForPageExtraParams('category', $category, $id_shop, true);
                if ($get_page_check > 0 && !$crawled) {
                    if ($id_customer > 0) {
                        $rule_customer_group = (int)$rcg->getCustomerQualification($get_page_check, $id_customer);
                        if ($rule_customer_group > 0) {
                            $flag = false;
                        }
                    }
                    elseif ($id_customer <= 0) {
                        $rule_visitors_group = $rcg->getVisitorQualification($get_page_check);
                        if ($rule_visitors_group > 0) {
                            $flag = false;
                        }
                    }
                    if ($flag == true) {
                        $flag = false;
                        return (int)$flag;
                    }
                    else {
                        $flag = true;
                        return (int)$flag;
                    }
                }
            }
        }
        $flag = true;
        return (int)$flag;
    }
    
    public function hookDisplayRcg($params)
    {
        if (Validate::isLoadedObject($params['product'])) {
            $product_class = $params['product'];
            $id = (int)$product_class->id_product;
        } else {
            $id = (int)$params['product']['id_product'];
        }
        $id = ($id <= 0) ? (int)Tools::getValue('id_product') : $id;
        $hide_items = (int)Configuration::get('RCG_PRODUCTS_VISIBLE');
        $flag = $this->crawlProductRestriction($id);
        if ($flag <= 0 && $hide_items > 0) {
            return $this->display(__FILE__, 'views/templates/hook/hidden.tpl');
        }
    }
}